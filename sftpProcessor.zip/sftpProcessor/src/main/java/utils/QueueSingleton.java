package utils;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class QueueSingleton {
	
	private QueueSingleton() {
		fileToProcessQueue = new  ConcurrentLinkedQueue<String>();
	}
	
	private static QueueSingleton queueSingletonInstance;
	private static ConcurrentLinkedQueue<String> fileToProcessQueue;
	
	public Queue<String> getQueue() {
		return fileToProcessQueue;
	}
	
	public static QueueSingleton getInstance() {
		if (queueSingletonInstance == null) {
			synchronized(QueueSingleton.class) {				
				if (queueSingletonInstance == null) {
					queueSingletonInstance = new QueueSingleton(); 
				}
			}
		}
		
		return queueSingletonInstance;
	}

}
