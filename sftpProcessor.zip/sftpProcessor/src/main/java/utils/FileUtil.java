package utils;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvMapReader;
import org.supercsv.prefs.CsvPreference;


public class FileUtil {

	public static void persistCsv(String filePath) throws SQLException {
		Connection connection = DbConnectionPool.getConnection();
		int batchSize = 2;

		CsvMapReader mapReader = null;
        CellProcessor[] processors = new CellProcessor[] {
                new Optional(), 
                new Optional(), 
                new Optional(), 
                new Optional(), 
                new Optional(), 
        };	
          
        try {
            connection.setAutoCommit(false);
 
            String sql = "INSERT INTO call_details (result_time, granularity_period, object_name, cell_id, call_attempt) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
 
            mapReader = new CsvMapReader(new FileReader(filePath),
                    CsvPreference.STANDARD_PREFERENCE);
 
            mapReader.getHeader(true); 
 
            String[] header = {"Result Time","Granularity Period","Object Name","Cell ID","CallAttemps"};
            //CallDetails bean = null;
 
            int count = 0;
            Map<String, Object> customMap;

            while ((customMap = mapReader.read(header, processors)) != null )  {
            	count+=1;
                String resultTime  = (String) customMap.get(header[0]);
            	int granularityPeriod = Integer.parseInt(((String) customMap.get(header[1])).trim());
                String objectName = (String) customMap.get(header[2]);
            	int cellId = Integer.parseInt(((String) customMap.get(header[3])).trim());
            	int callAttempts = Integer.parseInt(((String) customMap.get(header[4])).trim());

                
                statement.setString(1, resultTime);
                statement.setInt(2, granularityPeriod);
                statement.setString(3, objectName);
                statement.setInt(4, cellId);
                statement.setInt(5, callAttempts);

 
                statement.addBatch();
 
                if (count % batchSize == 0) {
                    statement.executeBatch();
                }
            }
 
            mapReader.close();
            statement.executeBatch(); 
            connection.commit();
        } catch (IOException ex) {
            System.err.println(ex);
        } catch (SQLException ex) {
            ex.printStackTrace();
 
            try {
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
	}
}
