package utils;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;

public class DbConnectionPool {
	   
    private DbConnectionPool(){ }

	    private static BasicDataSource dbPool = new BasicDataSource();
	     
	    static {
	    	dbPool.setDriverClassName("com.mysql.cj.jdbc.Driver");
	    	dbPool.setUrl("jdbc:mysql://127.0.0.1:3306/test?useSSL=false");
	    	dbPool.setUsername("root");
	    	dbPool.setPassword("root");
	        dbPool.setMinIdle(5);
	        dbPool.setMaxIdle(10);
	        dbPool.setMaxOpenPreparedStatements(100);
	    }
	     
	    public static Connection getConnection() throws SQLException {
	        return dbPool.getConnection();
	    }
	     
}
