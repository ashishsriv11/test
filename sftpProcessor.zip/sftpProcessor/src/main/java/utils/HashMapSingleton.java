package utils;

import java.util.HashMap;
import java.util.Map;

public class HashMapSingleton {
	private HashMapSingleton() {
		persistentMap = new HashMap<String, Integer>();
	}
	
	private static HashMapSingleton hashMapSingletonInstance;
	private static Map<String, Integer> persistentMap;
	
	public Map<String, Integer> getMap() {
		return persistentMap;
	}
	
	public static HashMapSingleton getInstance() {
		if (hashMapSingletonInstance == null) {
			synchronized(HashMapSingleton.class) {				
				if (hashMapSingletonInstance == null) {
					hashMapSingletonInstance = new HashMapSingleton(); 
				}
			}
		}
		
		return hashMapSingletonInstance;
	}
}
