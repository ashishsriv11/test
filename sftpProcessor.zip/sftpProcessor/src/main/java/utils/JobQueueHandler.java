package utils;

import java.util.List;


public class JobQueueHandler {
	
	public static void addToQueueWithPersistence(List<String> filePathList){
		
		for( String filePath: filePathList )
	    {
			if (!HashMapSingleton.getInstance().getMap().containsKey(filePath)) {
				HashMapSingleton.getInstance().getMap().put(filePath, 1);
				QueueSingleton.getInstance().getQueue().add(filePath);
				System.out.println(filePath);
			}
	    }
		
	}

}
