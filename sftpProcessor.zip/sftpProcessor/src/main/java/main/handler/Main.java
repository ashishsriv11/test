package main.handler;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Timer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import sftp.handler.SftpAdapter;
import sftp.handler.SftpCronJob;
import utils.FileUtil;
import utils.QueueSingleton;

public class Main {

	public static void main(String[] args) throws IOException {
		
		Runnable producer = new Runnable() {
			    public void run() {
			    	Timer t = new Timer();
					 SftpCronJob sftpCronJob = new SftpCronJob();
				     t.scheduleAtFixedRate(sftpCronJob, 0, 10000);
			    }
			};

		new Thread(producer).start();
			
		Runnable consumer = new Runnable () {
				public void run() {
					if (!QueueSingleton.getInstance().getQueue().isEmpty()) {
						String filePath = QueueSingleton.getInstance().getQueue().poll();
						System.out.println("out::" +filePath);

						String fileName = filePath.split("/")[filePath.split("/").length -1];
						try {
							String localFilePath = SftpAdapter.getRemoteFile(filePath, fileName);
							FileUtil.persistCsv(localFilePath);
							SftpAdapter.moveToProcessed(filePath, filePath.replace("incoming", "processed"));
						} catch (IOException e) {
							e.printStackTrace();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				} 				
			};	
		
		ExecutorService executor = Executors.newFixedThreadPool(100);
        
		while (true) {
        	if (!QueueSingleton.getInstance().getQueue().isEmpty()) {
                executor.execute(consumer);
        	}else {
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
        	
          }
	}

}
