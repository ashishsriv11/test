package model;

import java.sql.Date;


public class CallDetails {
  
	private String resultTime;
	private int granularityPeriod;
	private String objectName;
	private int cellID;
	private int callAttempts;
	
	public String getResultTime() {
		return resultTime;
	}
	public void setResultTime(String resultTime) {
		this.resultTime = resultTime;
	}
	public int getGranularityPeriod() {
		return granularityPeriod;
	}
	public void setGranularityPeriod(int granularityPeriod) {
		this.granularityPeriod = granularityPeriod;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public int getCellID() {
		return cellID;
	}
	public void setCellID(int cellID) {
		this.cellID = cellID;
	}
	public int getCallAttempts() {
		return callAttempts;
	}
	public void setCallAttempts(int callAttempts) {
		this.callAttempts = callAttempts;
	}
}
