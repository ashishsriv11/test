package sftp.handler;

import java.io.IOException;

import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.sftp.SFTPClient;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;

public class SftpConnector {
	
	private static String remoteHost = "127.0.0.1";
	private static String username = "foo";
	private static String password = "pass";
	private static SFTPClient sftpClient;
	private static SSHClient sshClient;
	private static SftpConnector SftpConnectorInstance;

	private SftpConnector() throws IOException {
		sshClient = getSshClient();
		sftpClient = getNewSftpClient(sshClient);

	}
	
	private static SSHClient getSshClient() throws IOException {
	    SSHClient client = new SSHClient();
	    client.addHostKeyVerifier(new PromiscuousVerifier());
	    client.connect(remoteHost);
	    client.authPassword(username, password);
	    return client;
	}
	
	private static SFTPClient getNewSftpClient(SSHClient sshClient) throws IOException {
	    SFTPClient sftpClient = sshClient.newSFTPClient();
	    
	    return sftpClient;
	}
	
	public SFTPClient getSFTPClient() {
        return sftpClient;
    }
	
	private SSHClient getSSHClient() {
        return sshClient;
    }
	
	public static SftpConnector getInstance() throws IOException {
		
		if (SftpConnectorInstance == null) {
			synchronized(SftpConnector.class) {
				if (SftpConnectorInstance == null) {
					SftpConnectorInstance = new SftpConnector();
				}
			}
		}else if (! SftpConnectorInstance.getSSHClient().isConnected()) {
			SftpConnectorInstance = new SftpConnector();
        }
		
		return SftpConnectorInstance;
	}	
}
