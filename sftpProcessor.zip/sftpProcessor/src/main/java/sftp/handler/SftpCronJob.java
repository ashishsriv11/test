package sftp.handler;

import java.io.IOException;
import java.util.List;
import java.util.TimerTask;

import utils.JobQueueHandler;

public class SftpCronJob extends TimerTask  {

	@Override
	   public void run() {
		try {
			List<String> filePathList =  SftpAdapter.getFileNames("/upload/incoming/");
			JobQueueHandler.addToQueueWithPersistence(filePathList);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	   }}
