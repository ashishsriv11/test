package sftp.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.schmizz.sshj.sftp.RemoteResourceInfo;
import net.schmizz.sshj.sftp.SFTPClient;

public class SftpAdapter {

//	private static String remoteFile = "/upload/incoming/a.txt";
	private static String localDir = "src/main/resources/";

	
	
	public static String getRemoteFile(String filePath, String fileName ) throws IOException {
		SFTPClient sftpClient  = SftpConnector.getInstance().getSFTPClient();
	    String localFilePath = localDir + fileName;
		sftpClient.get(filePath , localFilePath);
		
		return localFilePath;
	}
	
	public static void moveToProcessed(String oldPath, String newPath) throws IOException {
		SFTPClient sftpClient  = SftpConnector.getInstance().getSFTPClient();
		sftpClient.rename(oldPath, newPath);
	}
	
	public static List<String> getFileNames(String folderPath) throws IOException {
		List< String > fileNameList = new ArrayList< String >();
		
		SFTPClient sftpClient  = SftpConnector.getInstance().getSFTPClient();
		List< RemoteResourceInfo > files = sftpClient.ls(folderPath);
		for( RemoteResourceInfo file: files )
	    {
			fileNameList.add( file.getPath() );
	    }
		
		return fileNameList;
	}
	
}
